<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/components/section-border.blade.php ENDPATH**/ ?>