<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Model Viewer - Dark Theme</title>
    <link href='<?php echo e(url('assets/bootstrap/bootstrap.min.css')); ?>' rel='stylesheet'>
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
            padding-top: 20px;
        }

        a {
            color: #00bfff;
        }

        a:hover {
            color: #33ccff;
        }

        .sidebar {
            min-height: 100vh;
            background-color: #1e1e1e;
            border-right: 1px solid #333;
            padding: 1rem;
        }

        .active-link {
            font-weight: bold;
            color: #00bfff !important;
        }

        .card {
            background-color: #1e1e1e;
            color: #e0e0e0;
            border: 1px solid #333;
        }

        .card-title {
            font-weight: 600;
            font-size: 1.1rem;
            color: #00bfff;
        }

        .card-footer {
            border-top: 1px solid #333;
        }

        .btn-primary {
            background-color: #00bfff;
            border-color: #00bfff;
        }

        .btn-primary:hover {
            background-color: #33ccff;
            border-color: #33ccff;
        }

        .list-group-item {
            background-color: #2a2a2a;
            color: #e0e0e0;
            font-size: 0.875rem;
            border-color: #333;
        }

        .table {
            color: #e0e0e0;
        }

        .table th, .table td {
            background-color: #1e1e1e;
            border-color: #333;
        }

        .alert-info {
            background-color: #2c3e50;
            color: #00bfff;
            border: none;
        }

        .pagination .page-link {
            background-color: #1e1e1e;
            color: #00bfff;
            border: 1px solid #333;
        }

        .pagination .page-link:hover {
            background-color: #333;
        }

        .pagination .active .page-link {
            background-color: #00bfff;
            color: #000;
            border-color: #00bfff;
        }

        body > div > div > div.col-md-10 > nav > div.d-none.flex-sm-fill.d-sm-flex.align-items-sm-center.justify-content-sm-between > div:nth-child(1) > p {
            color: aliceblue !important;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h5 class="text-light">Models</h5>
                <ul class="nav flex-column">
                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($m == $model ? 'active-link' : ''); ?>" href="<?php echo e(route('models.index', $m)); ?>">
                                <?php echo e($m); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10">
                <h3 class="mt-3 text-info"><?php echo e($model ?? 'Select a Model'); ?></h3>

                <?php if($records->count()): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <?php $__currentLoopData = $records->first()->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($key); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php $__currentLoopData = $record->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e(\Str::limit($value, 50)); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($records->links('pagination::bootstrap-5')); ?>

                <?php elseif($model): ?>
                    <div class="alert alert-info">No records found for <strong><?php echo e($model); ?></strong>.</div>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $modelClass = "App\\Models\\$m";
                                $instance = class_exists($modelClass) ? $modelClass::first() : null;
                                $columns = $instance ? array_keys($instance->getAttributes()) : [];
                            ?>

                            <div class="mb-4 col-md-4">
                                <div class="shadow-sm card h-100">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($m); ?></h5>

                                        <?php if($columns): ?>
                                            <ul class="list-group list-group-flush">
                                                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item"><?php echo e($col); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <div class="mt-2 text-muted">No records found (or table is empty)</div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="bg-transparent card-footer">
                                        <a href="<?php echo e(route('models.index', $m)); ?>" class="btn btn-sm btn-primary">View Records</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/models/index.blade.php ENDPATH**/ ?>