<?php $__env->startSection('content'); ?>
    <h1>Create a new users</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('users.store')); ?>' method='POST'>
                <?php echo csrf_field(); ?>

                <div class='form-group'>
                    <label for='name'>Name</label>
                    <input type='text' class='form-control' id='name' name='name' required>
                </div>

                <div class='form-group'>
                    <label for='name'>Email</label>
                    <input type='text' class='form-control' id='email' name='email' required>
                </div>

                <div class='form-group'>
                    <label for='name'>Password</label>
                    <input type='password' class='form-control' id='password' name='password' required>
                </div>

                <div class='form-group'>
                    <label for='name'>Role</label>
                    <select name="role" id="" class="form-control">
                        <option value="waiter">Waiter</option>
                        <option value="counter">Counter</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <button type='submit' class='mt-3 btn btn-primary'>Create</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/users/create-users.blade.php ENDPATH**/ ?>