<?php $__env->startSection('content'); ?>
    <h1>Are you sure you want to delete this orders?</h1>

    <form action='<?php echo e(route('orders.destroy', $item->id)); ?>' method='GET'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type='submit' class='btn btn-danger'>Yes, Delete</button>
        <a href='<?php echo e(route('orders.index')); ?>' class='btn btn-secondary'>Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/orders/delete-orders.blade.php ENDPATH**/ ?>