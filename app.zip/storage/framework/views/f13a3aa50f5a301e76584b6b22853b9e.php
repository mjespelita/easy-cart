<a href="/">
    <img src="<?php echo e(url('assets/easy-cart-logo.jpg')); ?>" alt="" width="300px">
</a>
<?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>