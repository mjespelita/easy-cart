<?php $__env->startSection('content'); ?>
    <h1>Edit Products</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('products.update', $item->id)); ?>' method='POST'>
                <?php echo csrf_field(); ?>

        <div class='form-group'>
            
            <input hidden type='text' class='form-control' id='product_id' name='product_id' value='<?php echo e($item->product_id); ?>' required>
        </div>

        <div class='form-group'>
            <label for='name'>Name</label>
            <input type='text' class='form-control' id='name' name='name' value='<?php echo e($item->name); ?>' required>
        </div>

        <div class='form-group'>
            <label for='name'>Menu Type</label>
            <select name="types_id" class="form-control" required>
                <option value="" disabled selected>Select type</option>
                <?php $__empty_1 = true; $__currentLoopData = App\Models\Types::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="" disabled>No available types</option>
                <?php endif; ?>
            </select>
        </div>

        <div class='form-group'>
            <label for='name'>Description</label>
            <textarea name="description" id="" cols="30" class="form-control" rows="10" placeholder="Type here..." required><?php echo e($item->description); ?></textarea>
        </div>

        <!-- Real-time price preview -->
        <div class="p-4 form-group">
            <h1 id="formatted-price" style="font-weight: bold; font-size: 1.2rem;">₱<?php echo e(Smark\Smark\Math::convertToMoneyFormat($item->price)); ?></h1>
        </div>

        <div class='form-group'>
            <label for='name'>Price</label>
            <input type='number' class='form-control' id='price' name='price' value='<?php echo e($item->price); ?>' required>
        </div>

                <button type='submit' class='mt-3 btn btn-primary'>Update</button>
            </form>
        </div>
    </div>

    <!-- jQuery Script (make sure jQuery is loaded) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- jQuery logic -->
    <script>
        function formatMoney(value) {
            const number = parseFloat(value);
            if (isNaN(number)) return '₱0.00';
            return '₱' + number.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        $(document).ready(function () {
            $('#price').on('input', function () {
                const rawValue = $(this).val();
                $('#formatted-price').text(formatMoney(rawValue));
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/products/edit-products.blade.php ENDPATH**/ ?>