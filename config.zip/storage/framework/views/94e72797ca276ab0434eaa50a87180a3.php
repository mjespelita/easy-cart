
<!DOCTYPE html>
<html lang='<?php echo e(str_replace('_', '-', app()->getLocale())); ?>'>
    <head>
        <meta charset='utf-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>
        <meta name='author' content='Mark Jason Penote Espelita'>
        <meta name='keywords' content='keyword1, keyword2'>
        <meta name='description' content='Dolorem natus ab illum beatae error voluptatem incidunt quis. Cupiditate ullam doloremque delectus culpa. Autem harum dolorem praesentium dolorum necessitatibus iure quo. Et ea aut voluptatem expedita.'>

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link href='<?php echo e(url('assets/bootstrap/bootstrap.min.css')); ?>' rel='stylesheet'>
        <!-- FontAwesome for icons -->
        <link href='<?php echo e(url('assets/font-awesome/css/all.min.css')); ?>' rel='stylesheet'>
        <link rel='stylesheet' href='<?php echo e(url('assets/custom/style.css')); ?>'>
        <link rel='icon' href='<?php echo e(url('assets/easy-cart-logo.jpg')); ?>'>
    </head>
    <body class='font-sans antialiased'>

        <!-- Sidebar for Desktop View -->
        <div class='sidebar' id='mobileSidebar'>
            <div class='logo'>
                <img src='<?php echo e(url('assets/easy-cart-logo.jpg')); ?>' alt='' width='50%'>
            </div>
            <a href="<?php echo e(url('dashboard')); ?>" class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>

            

            <a href="<?php echo e(url('orders')); ?>" class="<?php echo e(request()->is('orders', 'create-orders', 'trash-orders', 'show-orders/*', 'edit-orders/*', 'delete-orders/*', 'orders-search*') ? 'active' : ''); ?>">
                <i class="fas fa-receipt"></i> <span class="text-danger fw-bold"><?php echo e(App\Models\Orders::count()); ?></span> All Orders
            </a>

            <a href="<?php echo e(url('preparing-orders')); ?>" class="<?php echo e(request()->is('preparing-orders', 'create-preparing-orders', 'trash-preparing-orders', 'show-preparing-orders/*', 'edit-preparing-orders/*', 'delete-preparing-orders/*', 'preparing-orders-search*') ? 'active' : ''); ?>">
                <i class="fas fa-recycle"></i> <span class="text-danger fw-bold"><?php echo e(App\Models\Orders::where('status', 'preparing')->count()); ?></span> Preparing Orders
            </a>

            <a href="<?php echo e(url('done-orders')); ?>" class="<?php echo e(request()->is('done-orders', 'create-done-orders', 'trash-done-orders', 'show-done-orders/*', 'edit-done-orders/*', 'delete-done-orders/*', 'done-orders-search*') ? 'active' : ''); ?>">
                <i class="fas fa-check"></i> <span class="text-danger fw-bold"><?php echo e(App\Models\Orders::where('status', 'done')->count()); ?></span> Done Orders
            </a>

            <a href="<?php echo e(url('products')); ?>" class="<?php echo e(request()->is('products', 'create-products', 'trash-products', 'show-products/*', 'edit-products/*', 'delete-products/*', 'products-search*') ? 'active' : ''); ?>">
                <i class="fas fa-box-open"></i> Products
            </a>

            <a href="<?php echo e(url('types')); ?>" class="<?php echo e(request()->is('types', 'create-types', 'trash-types', 'show-types/*', 'edit-types/*', 'delete-types/*', 'types-search*') ? 'active' : ''); ?>">
                <i class="fas fa-bars"></i> Types
            </a>

            <hr>
            <?php $__empty_1 = true; $__currentLoopData = App\Models\Types::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a target="_blank" href="<?php echo e(url('kitchen.php?type='.$type->id)); ?>" class="">
                    <i class="fas fa-utensils"></i> <?php echo e($type->name); ?> Orders Board
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <b>No Available Types...</b>
            <?php endif; ?>
            <hr>

            

            

            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(url('users')); ?>" class="<?php echo e(request()->is('users', 'create-users', 'trash-users', 'show-users/*', 'edit-users/*', 'delete-users/*', 'discounts-search*') ? 'active' : ''); ?>">
                    <i class="fas fa-users"></i> User Accounts
                </a>
                <a href="<?php echo e(url('discounts')); ?>" class="<?php echo e(request()->is('discounts', 'create-discounts', 'trash-discounts', 'show-discounts/*', 'edit-discounts/*', 'delete-discounts/*', 'discounts-search*') ? 'active' : ''); ?>">
                    <i class="fas fa-percentage"></i> Discount List
                </a>
            <?php endif; ?>

            <a href="/release-notes.html" class="">
                <i class="fas fa-earth"></i> Release Notes
            </a>

            <a href="<?php echo e(url('user/profile')); ?>">
                <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?>

            </a>

        </div>

        <!-- Top Navbar -->
        <nav class='navbar navbar-expand-lg navbar-dark'>
            <div class='container-fluid'>
                <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarNav'
                    aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation' onclick='toggleSidebar()'>
                    <i class='fas fa-bars'></i>
                </button>
            </div>
        </nav>

        <?php if (isset($component)) { $__componentOriginalf51e58d5cce915072d5188ae79588f9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf51e58d5cce915072d5188ae79588f9f = $attributes; } ?>
<?php $component = App\View\Components\MainNotification::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainNotification::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf51e58d5cce915072d5188ae79588f9f)): ?>
<?php $attributes = $__attributesOriginalf51e58d5cce915072d5188ae79588f9f; ?>
<?php unset($__attributesOriginalf51e58d5cce915072d5188ae79588f9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf51e58d5cce915072d5188ae79588f9f)): ?>
<?php $component = $__componentOriginalf51e58d5cce915072d5188ae79588f9f; ?>
<?php unset($__componentOriginalf51e58d5cce915072d5188ae79588f9f); ?>
<?php endif; ?>

        <div class='content'>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Bootstrap JS and dependencies -->
        <script src='<?php echo e(url('assets/bootstrap/bootstrap.bundle.min.js')); ?>'></script>

        <!-- Custom JavaScript -->
        <script src="<?php echo e(url('assets/custom/script.js')); ?>"></script>
        <script>
            function toggleSidebar() {
                document.getElementById('mobileSidebar').classList.toggle('active');
                document.getElementById('sidebar').classList.toggle('active');
            }
        </script>
    </body>
</html>
<?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/layouts/main.blade.php ENDPATH**/ ?>