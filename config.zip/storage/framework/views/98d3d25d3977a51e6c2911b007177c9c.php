<?php $__env->startSection('content'); ?>
    <h1>Edit Types</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('types.update', $item->id)); ?>' method='POST'>
                <?php echo csrf_field(); ?>
                
        <div class='form-group'>
            <label for='name'>Name</label>
            <input type='text' class='form-control' id='name' name='name' value='<?php echo e($item->name); ?>' required>
        </div>
    
                <button type='submit' class='btn btn-primary mt-3'>Update</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows 11Pro\_web\easy_cart\resources\views/types/edit-types.blade.php ENDPATH**/ ?>